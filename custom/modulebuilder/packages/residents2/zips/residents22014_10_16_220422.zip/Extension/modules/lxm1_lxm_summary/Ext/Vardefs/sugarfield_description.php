<?php
 // created: 2014-10-16 21:48:44
$dictionary['lxm1_lxm_summary']['fields']['description']['required']=true;
$dictionary['lxm1_lxm_summary']['fields']['description']['comments']='Full text of the note';
$dictionary['lxm1_lxm_summary']['fields']['description']['merge_filter']='disabled';
$dictionary['lxm1_lxm_summary']['fields']['description']['cols']='160';

 ?>