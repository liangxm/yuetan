<?php
 // created: 2014-10-16 21:56:57
$dictionary['lxm1_lxm_summary']['fields']['name']['default']='';
$dictionary['lxm1_lxm_summary']['fields']['name']['duplicate_merge']='disabled';
$dictionary['lxm1_lxm_summary']['fields']['name']['duplicate_merge_dom_value']='0';
$dictionary['lxm1_lxm_summary']['fields']['name']['merge_filter']='disabled';
$dictionary['lxm1_lxm_summary']['fields']['name']['unified_search']=false;

 ?>