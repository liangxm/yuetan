<?php 
 // created: 2014-10-16 22:04:22
$mod_strings['LBL_DESCRIPTION'] = '描述';
$mod_strings['LBL_NAME'] = '标题';

?>
