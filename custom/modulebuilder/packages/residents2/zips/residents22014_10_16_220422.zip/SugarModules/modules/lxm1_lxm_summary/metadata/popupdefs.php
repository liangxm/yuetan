<?php
$popupMeta = array (
    'moduleMain' => 'lxm1_lxm_summary',
    'varName' => 'lxm1_lxm_summary',
    'orderBy' => 'lxm1_lxm_summary.name',
    'whereClauses' => array (
  'name' => 'lxm1_lxm_summary.name',
),
    'searchInputs' => array (
  1 => 'name',
),
    'searchdefs' => array (
  'name' => 
  array (
    'name' => 'name',
    'width' => '10%',
  ),
),
    'listviewdefs' => array (
  'NAME' => 
  array (
    'width' => '20%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
    'name' => 'name',
  ),
  'DESCRIPTION' => 
  array (
    'type' => 'text',
    'label' => 'LBL_DESCRIPTION',
    'sortable' => false,
    'width' => '80%',
    'default' => true,
    'name' => 'description',
  ),
),
);
