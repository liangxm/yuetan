<?php
$module_name = 'lxm1_lxm_famliy';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 
          array (
            'name' => 'relationship',
            'studio' => 'visible',
            'label' => 'LBL_RELATIONSHIP',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'work_unit',
            'label' => 'LBL_WORK_UNIT',
          ),
          1 => 
          array (
            'name' => 'phone',
            'label' => 'LBL_PHONE',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'email',
            'label' => 'LBL_EMAIL',
          ),
          1 => 
          array (
            'name' => 'lxm1_lxm_residents_lxm1_lxm_famliy_name',
          ),
        ),
      ),
    ),
  ),
);
?>
