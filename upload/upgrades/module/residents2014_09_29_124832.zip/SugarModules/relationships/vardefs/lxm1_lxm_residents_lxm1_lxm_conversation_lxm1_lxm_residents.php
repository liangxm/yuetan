<?php
// created: 2014-09-29 12:48:30
$dictionary["lxm1_lxm_residents"]["fields"]["lxm1_lxm_residents_lxm1_lxm_conversation"] = array (
  'name' => 'lxm1_lxm_residents_lxm1_lxm_conversation',
  'type' => 'link',
  'relationship' => 'lxm1_lxm_residents_lxm1_lxm_conversation',
  'source' => 'non-db',
  'module' => 'lxm1_lxm_conversation',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_LXM1_LXM_RESIDENTS_LXM1_LXM_CONVERSATION_FROM_LXM1_LXM_CONVERSATION_TITLE',
);
