<?php
// created: 2014-09-29 12:48:29
$dictionary["lxm1_lxm_residents"]["fields"]["lxm1_lxm_residents_lxm1_lxm_famliy"] = array (
  'name' => 'lxm1_lxm_residents_lxm1_lxm_famliy',
  'type' => 'link',
  'relationship' => 'lxm1_lxm_residents_lxm1_lxm_famliy',
  'source' => 'non-db',
  'module' => 'lxm1_lxm_famliy',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_LXM1_LXM_RESIDENTS_LXM1_LXM_FAMLIY_FROM_LXM1_LXM_FAMLIY_TITLE',
);
