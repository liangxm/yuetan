<?php
// created: 2014-09-29 12:48:26
$dictionary["lxm1_lxm_conversation"]["fields"]["lxm1_lxm_conversation_lxm1_lxm_attachment"] = array (
  'name' => 'lxm1_lxm_conversation_lxm1_lxm_attachment',
  'type' => 'link',
  'relationship' => 'lxm1_lxm_conversation_lxm1_lxm_attachment',
  'source' => 'non-db',
  'module' => 'lxm1_lxm_attachment',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_LXM1_LXM_CONVERSATION_LXM1_LXM_ATTACHMENT_FROM_LXM1_LXM_ATTACHMENT_TITLE',
);
