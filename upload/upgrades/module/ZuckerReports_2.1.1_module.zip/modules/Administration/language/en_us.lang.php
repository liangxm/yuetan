<?php
$mod_strings['LBL_MANAGE_ZUCKERREPORTS2CONFIG'] = 'ZuckerReports Configuration';
$mod_strings['LBL_ZUCKERREPORTS2CONFIG'] = 'Set the ZuckerReports configuration parameters';
$mod_strings['LBL_ZUCKERREPORTS2CONFIG_DESC'] = 'Manage your ZuckerReports settings.';
$mod_strings['LBL_ZUCKERREPORTS2CONFIG_TITLE'] = 'ZuckerReports';
?>
