<?php
// created: 2012-06-15 10:55:29
$dictionary["zr2_ReportContainer"]["fields"]["zr2_reportcontainer_zr2_report"] = array (
  'name' => 'zr2_reportcontainer_zr2_report',
  'type' => 'link',
  'relationship' => 'zr2_reportcontainer_zr2_report',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_ZR2_REPORTCONTAINER_ZR2_REPORT_FROM_ZR2_REPORT_TITLE',
);
