<?php
// created: 2012-06-15 10:55:30
$dictionary["zr2_QueryTemplate"]["fields"]["zr2_reportparameterlink_zr2_querytemplate"] = array (
  'name' => 'zr2_reportparameterlink_zr2_querytemplate',
  'type' => 'link',
  'relationship' => 'zr2_reportparameterlink_zr2_querytemplate',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_ZR2_REPORTPARAMETERLINK_ZR2_QUERYTEMPLATE_FROM_ZR2_REPORTPARAMETERLINK_TITLE',
);
