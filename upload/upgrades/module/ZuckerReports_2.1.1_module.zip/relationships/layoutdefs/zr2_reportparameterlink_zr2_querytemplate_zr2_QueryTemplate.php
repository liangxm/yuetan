<?php
 // created: 2012-06-15 10:55:30
$layout_defs["zr2_QueryTemplate"]["subpanel_setup"]['zr2_reportparameterlink_zr2_querytemplate'] = array (
  'order' => 100,
  'module' => 'zr2_ReportParameterLink',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ZR2_REPORTPARAMETERLINK_ZR2_QUERYTEMPLATE_FROM_ZR2_REPORTPARAMETERLINK_TITLE',
  'get_subpanel_data' => 'zr2_reportparameterlink_zr2_querytemplate',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
