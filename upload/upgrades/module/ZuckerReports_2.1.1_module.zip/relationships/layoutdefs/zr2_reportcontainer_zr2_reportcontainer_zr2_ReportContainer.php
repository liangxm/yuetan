<?php
 // created: 2012-06-15 10:55:29
$layout_defs["zr2_ReportContainer"]["subpanel_setup"]['zr2_reportcontainer_zr2_reportcontainerzr2_reportcontainer_ida'] = array (
  'order' => 100,
  'module' => 'zr2_ReportContainer',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ZR2_REPORTCONTAINER_ZR2_REPORTCONTAINER_FROM_ZR2_REPORTCONTAINER_R_TITLE',
  'get_subpanel_data' => 'zr2_reportcontainer_zr2_reportcontainerzr2_reportcontainer_ida',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
